# Maekan Dashboard with ATERCYBER AI Chatbot

A complete dashboard with integrated ATERCYBER AI chatbot using their free API.

## Features

- Clean, modern dashboard interface
- Real-time chat with ATERCYBER AI (NITISH RANA 8B model)
- Conversation history
- Typing indicators
- Responsive design

## Setup

1. Open `index.html` in your browser
2. Start chatting with the AI assistant

## Files

- `index.html` - Main dashboard structure
- `style.css` - Styling and animations
- `app.js` - Chat functionality and ATERCYBER API integration

## API

Uses ATERCYBER's free API with the NITISH RANA 8B Instruct model.

## Usage

Simply type your message in the input field and press Send or hit Enter. The AI will respond using ATERCYBER's language model.
