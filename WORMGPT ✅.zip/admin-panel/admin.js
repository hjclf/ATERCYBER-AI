// Check admin authentication
const adminPassword = localStorage.getItem('adminAuth');
if (adminPassword !== 'NITISH_RANA_admin_2024') {
    const password = prompt('Enter admin password:');
    if (password === 'nightking_admin_2024') {
        localStorage.setItem('adminAuth', password);
    } else {
        alert('Invalid password');
        window.location.href = '/';
    }
}

let liveRefreshInterval = null;

// Tab switching
document.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const tab = link.dataset.tab;
        
        document.querySelectorAll('.nav-link').forEach(l => l.classList.remove('active'));
        document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active'));
        
        link.classList.add('active');
        document.getElementById(`${tab}-tab`).classList.add('active');
        
        // Clear live refresh when leaving live tab
        if (liveRefreshInterval) {
            clearInterval(liveRefreshInterval);
            liveRefreshInterval = null;
        }
        
        if (tab === 'dashboard') loadDashboard();
        if (tab === 'users') loadUsers();
        if (tab === 'live') {
            loadLiveActivity();
            liveRefreshInterval = setInterval(loadLiveActivity, 5000);
        }
        if (tab === 'sessions') loadSessions();
    });
});

// Logout
document.getElementById('logoutBtn').addEventListener('click', () => {
    localStorage.removeItem('adminAuth');
    window.location.href = '/';
});

// Add user modal
document.getElementById('addUserBtn').addEventListener('click', () => {
    document.getElementById('addUserModal').classList.add('active');
});

function closeAddUserModal() {
    document.getElementById('addUserModal').classList.remove('active');
    document.getElementById('newUserId').value = '';
    document.getElementById('newUsername').value = '';
    document.getElementById('newPassword').value = '';
}

function closeChatHistoryModal() {
    document.getElementById('chatHistoryModal').classList.remove('active');
}

async function createUser() {
    const userId = document.getElementById('newUserId').value.trim();
    const username = document.getElementById('newUsername').value.trim();
    const password = document.getElementById('newPassword').value.trim();
    
    if (!userId || !username || !password) {
        alert('All fields are required');
        return;
    }
    
    const response = await fetch('/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId, username, password })
    });
    
    if (response.ok) {
        alert('User created successfully');
        closeAddUserModal();
        loadUsers();
    } else {
        const error = await response.json();
        alert(error.error || 'Failed to create user');
    }
}

async function loadDashboard() {
    const response = await fetch('/admin/analytics');
    const stats = await response.json();
    
    document.getElementById('totalUsers').textContent = stats.totalUsers;
    document.getElementById('activeNow').textContent = stats.activeNow;
    document.getElementById('totalSessions').textContent = stats.totalSessions;
    document.getElementById('totalMessages').textContent = stats.totalMessages;
    
    // Load recent activity
    const activityResponse = await fetch('/admin/recent-activity');
    const activities = await activityResponse.json();
    
    const activityList = document.getElementById('recentActivity');
    activityList.innerHTML = '';
    
    activities.forEach(activity => {
        const item = document.createElement('div');
        item.className = 'activity-item';
        item.innerHTML = `
            <div class="activity-info">
                <div class="activity-avatar">${activity.userId.substring(0, 2).toUpperCase()}</div>
                <div class="activity-details">
                    <h4>${activity.username || activity.userId}</h4>
                    <p>${activity.action}</p>
                </div>
            </div>
            <div class="activity-time">${formatTime(activity.timestamp)}</div>
        `;
        activityList.appendChild(item);
    });
}

async function loadUsers() {
    const response = await fetch('/admin/users');
    const users = await response.json();
    
    const grid = document.getElementById('usersGrid');
    grid.innerHTML = '';
    
    users.forEach(user => {
        const isOnline = user.lastActive && (Date.now() - user.lastActive < 120000); // 2 min
        
        const card = document.createElement('div');
        card.className = 'user-card';
        card.innerHTML = `
            <div class="user-card-header">
                <div class="user-id">${user.userId}</div>
                <span class="user-status ${isOnline ? 'online' : 'offline'}">
                    ${isOnline ? '🟢 Online' : '⚫ Offline'}
                </span>
            </div>
            <div class="user-info">
                <div class="info-row">
                    <span class="info-label">Username:</span>
                    <span class="info-value">${user.username}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Sessions:</span>
                    <span class="info-value">${user.sessionCount || 0}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Last Active:</span>
                    <span class="info-value">${user.lastActive ? formatTime(user.lastActive) : 'Never'}</span>
                </div>
            </div>
            <div class="user-actions">
                <button class="icon-btn" onclick="viewUserHistory('${user.userId}')">📜 History</button>
                <button class="icon-btn danger" onclick="deleteUser('${user.userId}')">🗑️ Delete</button>
            </div>
        `;
        grid.appendChild(card);
    });
    
    // Update filter dropdown
    const filter = document.getElementById('userFilter');
    filter.innerHTML = '<option value="">All Users</option>';
    users.forEach(user => {
        const option = document.createElement('option');
        option.value = user.userId;
        option.textContent = `${user.username} (${user.userId})`;
        filter.appendChild(option);
    });
}

async function deleteUser(userId) {
    if (!confirm(`Delete user ${userId} and all their data?`)) return;
    
    const response = await fetch(`/admin/users/${userId}`, {
        method: 'DELETE'
    });
    
    if (response.ok) {
        loadUsers();
        loadDashboard();
    } else {
        alert('Failed to delete user');
    }
}

async function loadLiveActivity() {
    const response = await fetch('/admin/live-activity');
    const liveUsers = await response.json();
    
    const grid = document.getElementById('liveActivity');
    
    if (liveUsers.length === 0) {
        grid.innerHTML = '<p style="color: #a0a0a0; text-align: center; padding: 40px;">No active users right now</p>';
        return;
    }
    
    grid.innerHTML = '';
    
    liveUsers.forEach(user => {
        const card = document.createElement('div');
        card.className = 'live-card';
        
        const messagesHtml = user.recentMessages.slice(0, 5).map(msg => `
            <div class="live-message">
                <strong>${msg.role === 'user' ? '👤 User' : '🤖 AI'}:</strong>
                <p>${msg.content.substring(0, 150)}${msg.content.length > 150 ? '...' : ''}</p>
            </div>
        `).join('');
        
        const viewBtn = user.sessionId ? `<button class="icon-btn" onclick="viewLiveSession('${user.userId}', '${user.sessionId}')" style="margin-top: 12px; width: 100%;">👁️ View Full Chat</button>` : '';
        
        card.innerHTML = `
            <div class="live-card-header">
                <div class="live-user">${user.username} (${user.userId})</div>
                <span class="live-badge">LIVE</span>
            </div>
            <div class="user-info" style="margin-bottom: 16px;">
                <div class="info-row">
                    <span class="info-label">Current Session:</span>
                    <span class="info-value">${user.currentSession}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Messages:</span>
                    <span class="info-value">${user.messageCount}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Last Activity:</span>
                    <span class="info-value">${formatTime(user.lastActive)}</span>
                </div>
            </div>
            <div class="live-messages">
                ${messagesHtml || '<p style="color: #a0a0a0;">No messages yet</p>'}
            </div>
            ${viewBtn}
        `;
        grid.appendChild(card);
    });
}

async function viewLiveSession(userId, sessionId) {
    const response = await fetch(`/admin/sessions?userId=${userId}`);
    const sessions = await response.json();
    
    const session = sessions.find(s => s.id === sessionId || Object.keys(s).includes('messages'));
    
    if (session) {
        viewSessionHistory(session);
    }
}

async function loadSessions() {
    const userId = document.getElementById('userFilter').value;
    const url = userId ? `/admin/sessions?userId=${userId}` : '/admin/sessions';
    
    const response = await fetch(url);
    const sessions = await response.json();
    
    const list = document.getElementById('sessionsList');
    list.innerHTML = '';
    
    if (sessions.length === 0) {
        list.innerHTML = '<p style="color: #a0a0a0; text-align: center; padding: 40px;">No sessions found</p>';
        return;
    }
    
    sessions.forEach(session => {
        const card = document.createElement('div');
        card.className = 'session-card';
        card.onclick = () => viewSessionHistory(session);
        
        const firstMsg = session.messages.find(m => m.role === 'user');
        const preview = firstMsg ? firstMsg.content.substring(0, 100) : 'No messages';
        
        card.innerHTML = `
            <div class="session-header">
                <div class="session-title">${session.title || 'Untitled Session'}</div>
            </div>
            <div class="session-meta">
                <span>👤 ${session.userId}</span>
                <span>💬 ${session.messages.length} messages</span>
                <span>🕒 ${new Date(session.timestamp).toLocaleString()}</span>
            </div>
            <div class="session-preview">${preview}...</div>
        `;
        list.appendChild(card);
    });
}

async function viewUserHistory(userId) {
    const response = await fetch(`/admin/sessions?userId=${userId}`);
    const sessions = await response.json();
    
    document.getElementById('chatHistoryTitle').textContent = `Chat History - ${userId}`;
    const content = document.getElementById('chatHistoryContent');
    content.innerHTML = '';
    
    if (sessions.length === 0) {
        content.innerHTML = '<p style="color: #a0a0a0; text-align: center;">No chat history</p>';
    } else {
        sessions.forEach(session => {
            const sessionDiv = document.createElement('div');
            sessionDiv.innerHTML = `<h3 style="color: #76b900; margin-bottom: 12px;">${session.title || 'Session'} - ${new Date(session.timestamp).toLocaleString()}</h3>`;
            
            session.messages.forEach(msg => {
                const msgDiv = document.createElement('div');
                msgDiv.className = `history-message ${msg.role}`;
                msgDiv.innerHTML = `
                    <div class="history-message-header">
                        <span class="history-role">${msg.role === 'user' ? '👤 User' : '🤖 Assistant'}</span>
                    </div>
                    <div class="history-content">${msg.content}</div>
                `;
                sessionDiv.appendChild(msgDiv);
            });
            
            content.appendChild(sessionDiv);
        });
    }
    
    document.getElementById('chatHistoryModal').classList.add('active');
}

function viewSessionHistory(session) {
    document.getElementById('chatHistoryTitle').textContent = `${session.title || 'Session'} - ${session.userId}`;
    const content = document.getElementById('chatHistoryContent');
    content.innerHTML = '';
    
    session.messages.forEach(msg => {
        const msgDiv = document.createElement('div');
        msgDiv.className = `history-message ${msg.role}`;
        msgDiv.innerHTML = `
            <div class="history-message-header">
                <span class="history-role">${msg.role === 'user' ? '👤 User' : '🤖 Assistant'}</span>
            </div>
            <div class="history-content">${msg.content}</div>
        `;
        content.appendChild(msgDiv);
    });
    
    document.getElementById('chatHistoryModal').classList.add('active');
}

function formatTime(timestamp) {
    const now = Date.now();
    const diff = now - timestamp;
    
    if (diff < 60000) return 'Just now';
    if (diff < 3600000) return `${Math.floor(diff / 60000)}m ago`;
    if (diff < 86400000) return `${Math.floor(diff / 3600000)}h ago`;
    return new Date(timestamp).toLocaleDateString();
}

function refreshDashboard() {
    loadDashboard();
}

// Filter sessions by user
document.getElementById('userFilter').addEventListener('change', loadSessions);

// Initial load
loadDashboard();
